package SearchEngine;

import java.nio.file.*;
import java.io.IOException;
import java.util.*;

public class SearchEngine {

    // Méthode pour charger les stop words à partir d'un fichier
    public static Set<String> loadStopWords(String filePath) throws IOException {
        return new HashSet<>(Files.readAllLines(Paths.get(filePath)));
    }

    // Méthode pour lire un fichier et retourner un tableau de mots en filtrant les stop words
    public static String[] readFile(String filePath, Set<String> stopWords) throws IOException {
        String content = new String(Files.readAllBytes(Paths.get(filePath)));
        return Arrays.stream(content.split("\\s+"))  // Divise le contenu en mots
                     .filter(word -> !stopWords.contains(word.toLowerCase()))  // Filtre les stop words
                     .toArray(String[]::new);  // Retourne le tableau filtré
    }

    // Méthode pour calculer le TF
    public static Map<String, Double> calculateTF(String[] doc) {
        Map<String, Double> tfMap = new HashMap<>();
        double wordCount = doc.length;

        for (String word : doc) {
            tfMap.put(word, tfMap.getOrDefault(word, 0.0) + 1);
        }

        for (String word : tfMap.keySet()) {
            tfMap.put(word, tfMap.get(word) / wordCount);
        }

        return tfMap;
    }

    // Méthode pour calculer l'IDF
    public static Map<String, Double> calculateIDF(List<String[]> documents) {
        Map<String, Double> idfMap = new HashMap<>();
        double docCount = documents.size();

        for (String[] doc : documents) {
            for (String word : doc) {
                if (!idfMap.containsKey(word)) {
                    double count = 0.0;
                    for (String[] d : documents) {
                        if (Arrays.asList(d).contains(word)) {
                            count += 1;
                        }
                    }
                    idfMap.put(word, Math.log(docCount / (count + 1)));  // Ajouter 1 pour éviter la division par zéro
                }
            }
        }

        return idfMap;
    }

    // Méthode pour calculer le TF-IDF
    public static Map<String, Double> calculateTFIDF(Map<String, Double> tfMap, Map<String, Double> idfMap) {
        Map<String, Double> tfidfMap = new HashMap<>();

        for (String word : tfMap.keySet()) {
            double tfidf = tfMap.get(word) * idfMap.getOrDefault(word, 0.0);
            tfidfMap.put(word, tfidf);
        }

        return tfidfMap;
    }

    // Méthode pour calculer la similarité cosinus
    public static double calculateCosineSimilarity(Map<String, Double> doc1, Map<String, Double> doc2) {
        double dotProduct = 0.0;
        double normDoc1 = 0.0;
        double normDoc2 = 0.0;

        for (String word : doc1.keySet()) {
            dotProduct += doc1.get(word) * doc2.getOrDefault(word, 0.0);
            normDoc1 += Math.pow(doc1.get(word), 2);
        }

        for (String word : doc2.keySet()) {
            normDoc2 += Math.pow(doc2.get(word), 2);
        }

        return dotProduct / (Math.sqrt(normDoc1) * Math.sqrt(normDoc2));
    }

    // Méthode pour effectuer la recherche
    public static List<Map.Entry<String, Double>> search(String query, List<String[]> documents) {
        String[] queryWords = query.split(" ");
        Map<String, Double> queryTF = calculateTF(queryWords);

        Map<String, Double> idfMap = calculateIDF(documents);

        Map<String, Double> queryTFIDF = calculateTFIDF(queryTF, idfMap);

        Map<String, Double> similarities = new HashMap<>();

        for (int i = 0; i < documents.size(); i++) {
            Map<String, Double> docTF = calculateTF(documents.get(i));
            Map<String, Double> docTFIDF = calculateTFIDF(docTF, idfMap);

            double cosineSim = calculateCosineSimilarity(queryTFIDF, docTFIDF);
            similarities.put("Document " + (i + 1), cosineSim);
        }

        List<Map.Entry<String, Double>> sortedDocs = new ArrayList<>(similarities.entrySet());
        sortedDocs.sort((a, b) -> b.getValue().compareTo(a.getValue()));

        return sortedDocs;
    }

    // Méthode principale pour exécuter le programme
    public static void main(String[] args) {
        try {
            // Charger les stop words
            Set<String> stopWords = loadStopWords("stopwords-fr.txt");

            // Chemin vers les fichiers T1, T2, et T3
            String[] doc1 = readFile("T1.txt", stopWords);
            String[] doc2 = readFile("T2.txt", stopWords);
            String[] doc3 = readFile("T3.txt", stopWords);

            // Corpus de documents
            List<String[]> documents = Arrays.asList(doc1, doc2, doc3);

            // Requête de recherche
            String query = "voitures électriques";  // Remplacez par votre requête

            // Effectuer la recherche
            List<Map.Entry<String, Double>> results = search(query, documents);

            // Afficher les résultats
            for (Map.Entry<String, Double> result : results) {
                System.out.println(result.getKey() + ": " + result.getValue());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
